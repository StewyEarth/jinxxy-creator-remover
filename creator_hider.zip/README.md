# JinxxyCreatorRemover
Removes People you don't want to see when Scrolling Jinxxy.com
